from pathlib import Path
from urllib.parse import urljoin
from datetime import datetime, timezone
import json
import requests
from bs4 import BeautifulSoup

YEAR = 2026
MENU_URL = f'https://www.cbsa-asfc.gc.ca/trade-commerce/tariff-tarif/{YEAR}/menu-eng.html'
OUT = Path('raw-sources') / str(YEAR)
OUT.mkdir(parents=True, exist_ok=True)

session = requests.Session()
session.headers.update({'User-Agent':'Mozilla/5.0 CanCalc Phase4 Live Fetch'})
resp = session.get(MENU_URL, timeout=30)
resp.raise_for_status()
(OUT / "menu-eng.html").write_text(resp.text, encoding='utf-8')

soup = BeautifulSoup(resp.text, "html.parser")
records = []
for a in soup.find_all('a', href=True):
    href = urljoin(MENU_URL, a['href'])
    label = " \".join(a.get_text(" ", strip=True).split())
    lower = href.lower()
    if any(x in lower for x in ['.zip', ' .pdf'.strip(), '/html/', 'countries-pays', 'section-eng', 'concord']):
        if ' .zip'.strip() in lower:
            kind = 'zip'
        elif ' .pdf'.strip() in lower:
            kind = 'pdf'
        else:
            kind = 'html'
        records.append({'url': href, 'label': label, 'kind': kind, 'filename': href.split('/')[-1].split('?')[0]})
seen = {}
for r in records:
    seen[r['url']] = r
records = sorted(seen.values(), key=lambda r: (r['kind'], r['filename']))
index = {
    'fetched_at': datetime.now(timezone.utc).isoformat(),
    'tariff_year': YEAR,
    'source_menu': MENU_URL,
    'discovered_files': records,
}
(OUT / "source_index_real.json").write_text(json.dumps(index, indent=2), encoding='utf-8')
print(json.dumps(index, indent=2))
