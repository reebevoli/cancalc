from pathlib import Path
import json

YEAR = 2026
OUT = Path('output-data') / str(YEAR)
OUT.mkdir(parents=True, exist_ok=True)

# Replace these demo rows after real Access-table mapping is complete.
items = [
    {'tariff_year': YEAR, 'hs10': '8504409590', 'chapter': '85', 'description_en': 'Static converters, other', 'status': 'active', 'source_ref': 'Phase 4 scaffold'},
    {'tariff_year': YEAR, 'hs10': '8708309000', 'chapter': '87', 'description_en': 'Brakes and servo-brakes; parts thereof, other', 'status': 'active', 'source_ref': 'Phase 4 scaffold'}
]
rates = [
    {'tariff_year': YEAR, 'hs10': '8504409590', 'treatment_code': 'MFN', 'treatment_label': 'Most-Favoured-Nation Tariff', 'rate_text': 'Free', 'rate_numeric': 0, 'rate_type': 'free', 'source_ref': 'Phase 4 scaffold'},
    {'tariff_year': YEAR, 'hs10': '8708309000', 'treatment_code': 'MFN', 'treatment_label': 'Most-Favoured-Nation Tariff', 'rate_text': '6.5%', 'rate_numeric': 6.5, 'rate_type': 'ad_valorem', 'source_ref': 'Phase 4 scaffold'}
]
(OUT / "normalized_items_demo.json").write_text(json.dumps(items, indent=2), encoding='utf-8')
(OUT / "normalized_rates_demo.json").write_text(json.dumps(rates, indent=2), encoding='utf-8')
