from pathlib import Path
import json, zipfile

YEAR = 2026
RAW = Path('raw-sources') / str(YEAR)
report = []
for archive in RAW.glob('*.zip'):
    with zipfile.ZipFile(archive) as z:
        names = z.namelist()
    report.append({
        'archive': archive.name,
        'members': names,
        'database_like_files': [n for n in names if n.lower().endswith(('.mdb', '.accdb', '.csv', '.txt'))]
    })
(RAW / "access_zip_report.json").write_text(json.dumps(report, indent=2), encoding='utf-8')
print(json.dumps(report, indent=2))
