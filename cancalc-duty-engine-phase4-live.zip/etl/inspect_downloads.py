from pathlib import Path
import json

YEAR = 2026
RAW = Path('raw-sources') / str(YEAR)
index = json.loads((RAW / "source_index_real.json").read_text(encoding='utf-8'))
summary = {
    'tariff_year': YEAR,
    'counts_by_kind': {},
    'files': [r['filename'] for r in index['discovered_files']]
}
for rec in index['discovered_files']:
    summary['counts_by_kind'][rec['kind']] = summary['counts_by_kind'].get(rec['kind'], 0) + 1
print(json.dumps(summary, indent=2))
