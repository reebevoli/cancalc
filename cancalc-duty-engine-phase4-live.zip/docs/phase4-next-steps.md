# Phase 4 Next Steps

1. Inspect the downloaded source index and identify the Access ZIP filename.
2. Expand ZIP extraction to locate MDB or ACCDB members.
3. Map real tariff item tables and treatment columns.
4. Normalize descriptions, rates, and change flags.
5. Emit chapter-split browser bundles from real rows.
6. Replace demo normalized files with real parsed outputs.
