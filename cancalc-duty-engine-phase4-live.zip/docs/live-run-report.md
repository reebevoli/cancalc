# Phase 4 Live Run Report

## Menu fetch
- URL: https://www.cbsa-asfc.gc.ca/trade-commerce/tariff-tarif/2026/menu-eng.html
- Status: 200

## Discovery summary
- Files discovered: 4
- Files downloaded during live run: 3
- Kind counts: {"html": 2, "pdf": 1, "zip": 1}

## Notes
This package uses the real published CBSA 2026 menu page as the discovery source.
HTML pages were downloaded when available, and binary assets were probed live with selective download for smaller files.
This keeps the workflow realistic without forcing a heavyweight full-source mirror during the first live attempt.
